<?php

function print_shape($shape)
{
  $dim = $shape['dim'];
  foreach($dim as $r=>$row)
  {
    foreach($row as $c=>$cell)
    {
      echo "|";
      echo $dim[$r][$c]? "X" : " ";
    }
    echo "|<br/>";
  }
}

$colors = array(
  '01_White'=>array(
                  'alias'=>'white',
                  'hex'=>"#F4F4F4",
                  'class'=>'01_White'
                ),
  '02_Tan'=>array(
                  'alias'=>'tan',
                  'hex'=>"#E0BD95",
                  'class'=>'02_Tan'
                ),
  '11_Black'=>array(
                  'alias'=>'black',
                  'hex'=>"#1B2A34",
                  'class'=>'11_Black'
                ),
  '23_Pink'=>array(
                  'alias'=>'pink',
                  'hex'=>"#FF879C",
                  'class'=>'23_Pink'
                ),
  '38_Light_Green'=>array( 
                  'alias'=>'lightgreen',
                  'hex'=>"#ADD9A8",
                  'class'=>'38_Light_Green'
                ),
  '47_Dark_Pink'=>array(
                  'alias'=>'darkpink',
                  'hex'=>"#D05098",
                  'class'=>'47_Dark_Pink'
                ),
  '62_Light_Blue'=>array(
                  'alias'=>'lightblue',
                  'hex'=>"#97CBD9",
                  'class'=>'62_Light_Blue'
                ),
  '80_Dark_Green'=>array(
                  'alias'=>'darkgreen',
                  'hex'=>"#00852B",
                  'class'=>'80_Dark_Green'
                ),
  '85_Dark_Bluish_Gray'=>array(
                  'alias'=>'darkbluishgray',
                  'hex'=>"#646464",
                  'class'=>'85_Dark_Bluish_Gray'
                ),
  '86_Light_Bluish_Gray'=>array(
                  'alias'=>'lightbluishgray',
                  'hex'=>"#969696",
                  'class'=>'86_Light_Bluish_Gray'
                ),
  '88_Reddish_Brown'=>array(
                  'alias'=>'reddishbrown',
                  'hex'=>"#5F3109",
                  'class'=>'88_Reddish_Brown'
                ),
  '99_Very_Light_Bluish_Gray'=>array(
                  'alias'=>'vlightbluishgray',
                  'hex'=>"#C0C0C0",
                  'class'=>'99_Very_Light_Bluish_Gray'
                ),
  '69_Dark_Tan'=>array(
                  'alias'=>'darktan',
                  'hex'=>"#897D62",
                  'class'=>'69_Dark_Tan'
                ),
  '26_Light_Salmon'=>array(
                  'alias'=>'lightsalmon',
                  'hex'=>"#F9B7A5",
                  'class'=>'26_Light_Salmon'
                )
);

$s1 = array(
    'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x1"
 );

$s2a = array(
    'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
    'color'=>NULL,
    'item'=>"1x2"
 );

$s2b = array(
    'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
   'color'=>NULL,
   'item'=>"2x1"
 );

$s3 = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
   ),
  'color'=>NULL,
  'item'=>"2x2"
 );

 $s4a = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner"
 );

$s4b = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(0,1,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_90"
 );

$s4c = array(
   'dim'=> array(
    0=>array(0,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_180"
 );

$s4d = array(
   'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_270"
 );

$s5a = array(
   'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(1,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x3"
 );

$s5b = array(
   'dim'=> array(
    0=>array(1,1,1,0,0,0,0,0),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"3x1"
 );

$s6a = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(1,1,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x3"
 );

$s6b = array(
   'dim'=> array(
    0=>array(1,1,1,0,0,0,0,0),
    1=>array(1,1,1,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"3x2"
 );
 
$s7a = array(
   'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(1,0,0,0,0,0,0,0),
    3=>array(1,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x4"
 );
 
$s7b = array(
   'dim'=> array(
    0=>array(1,1,1,1,0,0,0,0),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x1"
 );
 
$s8a = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(1,1,0,0,0,0,0,0),
    3=>array(1,1,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x4"
 );
 
$s8b = array(
   'dim'=> array(
    0=>array(1,1,1,1,0,0,0,0),
    1=>array(1,1,1,1,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x2"
 );
 
$s9 = array(
   'dim'=> array(
    0=>array(1,1,1,1,0,0,0,0),
    1=>array(1,1,1,1,0,0,0,0),
    2=>array(1,1,1,1,0,0,0,0),
    3=>array(1,1,1,1,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x4"
 );
 
$s10a = array(
   'dim'=> array(
    0=>array(1,1,1,1,0,0,0,0),
    1=>array(1,1,1,1,0,0,0,0),
    2=>array(1,1,0,0,0,0,0,0),
    3=>array(1,1,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x4_Corner"
 );
 
 $s10b = array(
   'dim'=> array(
    0=>array(1,1,1,1,0,0,0,0),
    1=>array(1,1,1,1,0,0,0,0),
    2=>array(0,0,1,1,0,0,0,0),
    3=>array(0,0,1,1,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x4_Corner_90"
 );
 
 $s10c = array(
   'dim'=> array(
    0=>array(0,0,1,1,0,0,0,0),
    1=>array(0,0,1,1,0,0,0,0),
    2=>array(1,1,1,1,0,0,0,0),
    3=>array(1,1,1,1,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x4_Corner_180"
 );
 
 $s10d = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(1,1,1,1,0,0,0,0),
    3=>array(1,1,1,1,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"4x4_Corner_270"
 );
 
 $s11a = array(
   'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(1,0,0,0,0,0,0,0),
    3=>array(1,0,0,0,0,0,0,0),
    4=>array(1,0,0,0,0,0,0,0),
    5=>array(1,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x6"
 );
 
 $s11b = array(
   'dim'=> array(
    0=>array(1,1,1,1,1,1,0,0),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"6x1"
 );
 
 $s12a = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(1,1,0,0,0,0,0,0),
    3=>array(1,1,0,0,0,0,0,0),
    4=>array(1,1,0,0,0,0,0,0),
    5=>array(1,1,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x6"
 );
 
 $s12b =array(
   'dim'=> array(
    0=>array(1,1,1,1,1,1,0,0),
    1=>array(1,1,1,1,1,1,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"6x2"
 );
 
 $s13a = array(
   'dim'=> array(
    0=>array(1,0,0,0,0,0,0,0),
    1=>array(1,0,0,0,0,0,0,0),
    2=>array(1,0,0,0,0,0,0,0),
    3=>array(1,0,0,0,0,0,0,0),
    4=>array(1,0,0,0,0,0,0,0),
    5=>array(1,0,0,0,0,0,0,0),
    6=>array(1,0,0,0,0,0,0,0),
    7=>array(1,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x8"
 );
 
 $s13b = array(
   'dim'=> array(
    0=>array(1,1,1,1,1,1,1,1),
    1=>array(0,0,0,0,0,0,0,0),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"8x1"
 );
 
 $s14a = array(
   'dim'=> array(
    0=>array(1,1,0,0,0,0,0,0),
    1=>array(1,1,0,0,0,0,0,0),
    2=>array(1,1,0,0,0,0,0,0),
    3=>array(1,1,0,0,0,0,0,0),
    4=>array(1,1,0,0,0,0,0,0),
    5=>array(1,1,0,0,0,0,0,0),
    6=>array(1,1,0,0,0,0,0,0),
    7=>array(1,1,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x8"
 );
 
 $s14b = array(
   'dim'=> array(
    0=>array(1,1,1,1,1,1,1,1),
    1=>array(1,1,1,1,1,1,1,1),
    2=>array(0,0,0,0,0,0,0,0),
    3=>array(0,0,0,0,0,0,0,0),
    4=>array(0,0,0,0,0,0,0,0),
    5=>array(0,0,0,0,0,0,0,0),
    6=>array(0,0,0,0,0,0,0,0),
    7=>array(0,0,0,0,0,0,0,0)
  ),
  'color'=>NULL,
  'item'=>"8x2"
 );

$shapes = array(
  '1x1'=> $s1,
  '1x2'=> $s2a,
  '2x1'=> $s2b,
  '2x2'=> $s3,
  '2x2_Corner'=> $s4a,
  '2x2_Corner_90'=> $s4b,
  '2x2_Corner_180'=> $s4c,
  '2x2_Corner_270'=> $s4d,
  '1x3'=> $s5a,
  '3x1'=> $s5b,
  '2x3'=> $s6a,
  '3x2'=> $s6b,
  '1x4'=> $s7a,
  '4x1'=> $s7b,
  '2x4'=> $s8a,
  '4x2'=> $s8b,
  '4x4'=> $s9,
  '4x4_Corner'=> $s10a,
  '4x4_Corner_90'=> $s10b,
  '4x4_Corner_180'=> $s10c,
  '4x4_Corner_270'=> $s10d,
  '1x6'=> $s11a,
  '6x1'=> $s11b,
  '2x6'=> $s12a,
  '6x2'=> $s12b,
  '1x8'=> $s13a,
  '8x1'=> $s13b,
  '2x8'=> $s14a,
  '8x2'=> $s14b
  );


/*
//print_r($shapes['s1']); //gets all data for shape s1
foreach ($shapes as $s)
{
  echo "<pre>";
  print_shape($s);
  echo "</pre>";
}
*/

//echo json_encode($shapes['s14']);





/*
//js console code

var s14 = {"dim":[[1,1,0,0,0,0,0,0],[1,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0]],"color":"#000000"}
console.log(s14);
s14.color = "#F11111";
console.log(s14);

*/

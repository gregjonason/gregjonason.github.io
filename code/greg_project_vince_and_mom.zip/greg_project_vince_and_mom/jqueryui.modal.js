// JavaScript Document
var modal = {
	modal:{},
	ajax:{},
	modal_id:'modal_window',
	is_open:0,
	add_container:function(){
		var container = document.getElementById(this.modal_id);
		if (!container){
			$('body').append('<div id="'+this.modal_id+'"></div>');
			this.log('modal div added');
		}
	},
	"log":function(x){
	},

	open:function(y, title){
		this.add_container();
 		if (this.modal.dialog){
			this.close();
			//create a modal div for all the content to be in
        }
        if (typeof(y) != 'object'){
        	var x = {};
            if (title){
            	x.title=title;
           	}
            x.content=y;
        }else{
        	var x = y;
        }


       //put the content in the div
       $('#'+this.modal_id).html(x.content);
        var modal_config={
     	'closeOnEscape':x.closeOnEscape==false?x.closeOnEscape:true,
			'closeText':x.closeText?x.closeText:'close',
			'dialogClass':x.dialogClass?x.dialogClass:'',

			'modal':true,
			'width':x.width?x.width:'auto',
            'height':x.height?x.height:'auto',

			'minWidth':x.minWidth?x.minWidth:false,
			'maxWidth':x.maxWidth?x.maxWidth:false,
			'minHeight':x.minHeight?x.minHeight:false,
			'maxHeight':x.maxHeight?x.maxHeight:false,
			'draggable':x.draggable?x.draggable:false,
			'resizable':x.resizable?x.resizable:false,
			'buttons':x.buttons?x.buttons:{},
   		'title':x.title?x.title:'',
   		'position': x.position?x.position:'center',
			'close':x.close?x.close:function(){ modal.bind_click('off'); modal.is_open=0; },
			'open': x.open?x.open:function(){ if ( x.clickToClose == undefined || x.clickToClose ) { modal.bind_click();  } if (typeof(x.callback)=='function'){x.callback();}; }
         };

        this.is_open=1;
		this.modal = $('#'+this.modal_id).dialog(modal_config);
		if (!this.modal){
			this.log('unable to load dialog');
		}


		(modal_config.title.search(/\w/) == -1) ? $('.ui-dialog .ui-dialog-titlebar').removeClass('ui-widget-header') : $('.ui-dialog .ui-dialog-titlebar').addClass('ui-widget-header');


		(x.title_bar) ? this.title_bar(x.title_bar) : this.title_bar();
		window.focus();

		return true;

	},

	bind_click:function(x){
		(x == 'off') ? $('.ui-widget-overlay').unbind('click') : $('.ui-widget-overlay').bind('click', function(){modal.close();});
	},

	title_bar:function(x){
		(x =='off') ? $('.ui-dialog-titlebar').hide() : $('.ui-dialog-titlebar').show();
	},

	close:function(){
		try{
			this.modal.dialog('close');
			$('#'+this.modal_id).html('');
			this.is_open=0;
		}catch(e){}
	  },

	 url:function(x){
     try{
     	if (typeof(x.data) != 'object'){
        	x.data = {popup:1};
        }else{
        	x.data.popup=1;
        }
		  this.ajax = $.ajax({
				url:x.url,
				type: x.type ? x.type: 'get',
				data:x.data,
				success:function(data){
                		x.content = data;
						modal.open(x);

				}
			});
			return false;
        }catch(e){
        	alert("MODAL URL: "+e);
        }
	  }
};

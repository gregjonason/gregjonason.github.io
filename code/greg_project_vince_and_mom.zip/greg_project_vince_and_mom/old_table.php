<table border="1">
	<thead width="100">
		<tr>
			<th><font face="Courier New">col id --><br />row id<br />|</br />V</font></th>
			<?php for($i=1;$i<$COL;$i++): ?>
				<th><?php echo $i ?></th>
			<?php endfor; ?>
		</tr>
	</thead>
	<tbody>
		<?php $curr_row = 0;
			foreach($master as $k=>$l):
			if($curr_row != $l['row']): ?>
			<tr>
			  <td>
					<?php	echo $l['row']; $curr_row = $l['row']; ?>
				</td>
				<?php for($i=1; $i<$COL; $i++ ): ?>
					<?php $row = "$curr_row-$i";  if($master[$row]['row'] == $curr_row): ?>
						<td>
							<?php echo $master[$row]['item'] . "<br />" . $master[$row]['color']; ?>
						</td>
					<?php else:?>
						<td></td>
					<?php endif; ?>
			  <?php endfor; ?>
			<?php endif; ?>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

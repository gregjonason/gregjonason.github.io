<?php
ini_set("display_errors",true);
error_reporting(E_ALL);

require_once('shapes.php');
?>

<html>
	<head>
		<script src="//code.jquery.com/jquery-2.2.0.min.js"></script>

		<!-- We use jquery ui for the modal -->
		<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
	  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>

		<!-- We use this modal class that Robert wrote. It simplifies using jqueryui.  It is not essential. -->
		<script src="jqueryui.modal.js"></script>
		<style>
			<?php
			//create the classes that will put the default color of the shapes
				foreach($colors as $name=>$value)
				{
					echo "." . $value['alias'] . " {\nbackground-color: " . $value['hex'] . ";\n}\n";
				}
			?>

			td{
				padding:0;
				margin:0;
			}
			td div{
				min-width:10px;
				min-height:10px;
				margin: 0;
				padding:0;
			}
			#frame{
				background-color: #000;
				margin: 20px;
				padding:10px;
				display: inline-block;
			}
			#modal{
				font-size: 12px;
			}

		</style>

	</head>
<body>

<?php
//GLOBAL VARIABLES
// for the number of columns
$COL = 170;

// open a text file called 'myfile.txt' and set it to append
//Tuan: changed to 'w' so that multiple runs of this script will not keep adding repeated content
$myfile = fopen('./myfile.txt', 'w') or die("Unable to open file!");
fwrite($myfile, "");//clear out the file content before running

// assign what to search for in the 'buildinginstruction.html' file
$search = 'row';

// read the 'buildinginstruction.html' file contents and store it into an array called $lines
$lines = file('buildinginstruction.html') or die('Could not read file!');



// this function parses out the row and column #'s from each of the lines found by the foreach loop below
function parse($line)
{
	global $colors, $shapes;
	$line = preg_replace('/Ministeck_/', '', $line);
	$A = preg_split("/[\s,:]+/", trim($line));

	$r = array(
		"row" 		=> $A[1]-1,
		"column" 	=> $A[3]-1,
		"item"		=> $A[4] == "(field" ? "covered" : $A[4],
		"color"		=> $A[5] == "covered)" ? NULL : $colors[$A[5]],
		"shape"		=> $A[4] == "(field" ? NULL : $shapes[$A[4]]
	);//$r array

	return $r;
}//parse

function create_canvas($master)
{
	//we need to instantiate a canvas matrix
	$canvas = array();

	//loop through $master and get values of row and column to populate the canvas
	//Determine which cells belong to a particular shape
	//as we look through master, get the row then offset it by the number of dim cells =1. do the same for columns.
	foreach($master as $m)
	{
		//we put null in the shape field of the cells that are "(field covered)" so we skip those
		if( isset($m['shape']) )
		{
			$cell_content = array();//this is the information we want each cell to have
			//get coordinates and set this class to each of the cells in the canvas
			$current_row = $m['row'];
			$current_column = $m['column'];

			//create a string that will be use as a class for this particular shape's instance
			//this will be used by JS later to let it know how cells are grouped to form a shape
			$shape_class = "s_{$current_row}_{$current_column}";
			$shape_color = $m['color']['alias'];
			$shape_group = $shape_class;

			//set the default color as the class of the cell. Also add a class called canvas_cell so we can specify click event in JS later
			$cell_content['class'] = "{$m['color']['alias']} canvas_cell $shape_class";
			$cell_content['color'] = $shape_color;
			$cell_content['group'] = $shape_group;

			//push all the data into the canvas cell
			//$canvas[$current_row][$current_cell] = $cell_content;
			//now we go through the shape[dim] array of the current thing item we are considering and put the cell content in canvas for its corresponding cells
			foreach($m['shape']['dim'] as $r=>$dim_row)
			{
				foreach($dim_row as $c=>$dim_col)
				{
					if($dim_col==1)//if the dim field is 1 then we add content
					{
						//offset from the current canvas cell
						//so if the current canvas cell is 0,0 and the shape we have has the following dim array
						/*
						1,1,0
						1,0,0
						0,0,0
						*/
						//Then, $r and $c start at 0 so (0,0) of canvas will get cell content
						//Next, $r==0, $c==1, or (0,1) of dim has a 1, so (0,1) of canvas will get content
						//Next, $r==0, $c==2, or (0,2) of dim has a 0, so (0,2) of canvas will get content
						//Next, $r==1, $c==0, or (1,0) of dim has a 1, so (1,0) of canvas will get content...

						//special case for this shape since it doesn't start in 0,0 of the 3x3 matrix, so we manually set the values
						if($m['shape']['item'] == '2x2_Corner_180')
						{
							$canvas[$current_row][$current_column] = $cell_content;
							$canvas[$current_row + $r][$current_column] = $cell_content;
							$canvas[$current_row + $r][$current_column - 1] = $cell_content;
						}
						else
						{
							$canvas[$current_row + $r][$current_column + $c] = $cell_content;
						}
					}//fi
				}//hcaerof
			}//hcaerof
		}//fi
	}//hcaerof
	//sort each of the rows by keys because of the order that we put the cells in the canvas, they are out of order
	foreach($canvas as $k=>$row)
	{
		ksort($row);
		$canvas[$k] = $row;
	}
	return $canvas;
}//create_canvas


// change the 'false' value in the $found variable to a 'true' value when there is a match to 'row' in the $lines array and print it out as $line
// also writes the matched contents of the line to 'myfile.txt'
$found = false;
$row_val = 0;
$master = array();

foreach($lines as $line)
{
  if(strpos($line, $search) !== false)
	{
    $found = true;
		$r = parse($line);
		//fwrite($myfile, $json);

		$new_row_val = $r['row'];
		$k = "{$r['row']}-{$r['column']}";
		$master[$k] = $r;

		if($row_val != $new_row_val)
		{
			$row_val = $new_row_val;
		}
	}
}

//build the canvas. this puts the classes in each cell so that we can use it in the web page
$canvas = create_canvas($master);

fclose($myfile);
?>

<div id="frame" >
<table id="canvas_table">
	<?php foreach($canvas as $row): ?>
		<tr>
			<?php foreach($row as $cell): ?>
				<td>
						<div class="<?php echo $cell['class']; ?>"
							data-color="<?php echo $cell['color']; ?>"
							data-group="<?php echo $cell['group']; ?>"
						</div>
				</td>
			<?php endforeach; ?>
		</tr>
	<?php endforeach; ?>
</table>
<div>

<!-- modal -->
<div id="modal_content" style="display:none;">
	<?php foreach($colors as $name=>$value): ?>
		<label>
			<input type="radio" name="color"
				value="<?php echo $value['alias'] ?>"
				id="<?php echo $value['alias'] ?>" />
				<?php echo $value['alias'] ?>
		</label>
	<?php endforeach; ?>

</div>
<!-- /modal -->

</body>

<script>
$(function(){
	$(".canvas_cell").click(function(){
		var d = $(this).data(); //this is the data in the element that we use to discern the groupings and color
		//Uncommenting the console below to see it in console
		//console.log($(this).data());

		//set the current color as the checked radio
		$("input[name=color]").attr('checked', false);
		$("input[name=color]:input[value='" + d.color + "']").attr('checked', true);

		var dialogContent = $("#modal_content").html(); //this is the content in the modal_content div that will display
		modal.open(
			{
				'title': "Select a color",
				'content':dialogContent,
				'clickToClose':false,
				'draggable':true,
				'position':{ my: "center", at: "top+20%", of: window },
				'buttons':{
					'cancel':function(){
						modal.close();
					},//cancel button
					'set':function(){
						//call the set_color function that will change the color of the cells
						var selected_color = $('input[name=color]:radio:checked').val();
						set_color(d.group, d.color,selected_color);
						modal.close();
					}//set buttom
				},//buttons
				open: function(event, ui) {
								$('input[name=color]:radio:checked').focus();
								var selected_color = $('input[name=color]:radio:checked').val();
								$("input[name=color]:radio").click(function(){
									selected_color = $('input[name=color]:radio:checked').val();
									//console.log(selected_color);
							});
						}//open
			}//modal json
		);//modal
	});//click
});

function set_color(group, curr_color, noo_color)
{
	$('.' + group).removeClass(curr_color);//remove the old color
	$('.' + group).addClass(noo_color);//add the new color
	$('.' + group).data('color',noo_color);//update the color value that we have in the data
	//console.log($('.' + group).data());
}
</script>
</html>

<?php

function print_shape($shape)
{
  $dim = $shape['dim'];
  foreach($dim as $r=>$row)
  {
    foreach($row as $c=>$cell)
    {
      echo "|";
      echo $dim[$r][$c]? "X" : " ";
    }
    echo "|<br/>";
  }
}

$colors = array(
  '601_Black'=>array(
                  'alias'=>'black',
                  'hex'=>"#000000",
                  'class'=>'601_Black'
                ),
  '635_Grey_1'=>array(
                  'alias'=>'gray1',
                  'hex'=>"#585858",
                  'class'=>'635_Grey_1'
                ),
  '636_Grey_2'=>array(
                  'alias'=>'gray2',
                  'hex'=>"#707070",
                  'class'=>'636_Grey_2'
                ),
  '637_Grey_3'=>array(
                  'alias'=>'gray3',
                  'hex'=>"#888888",
                  'class'=>'637_Grey_3'
                ),
  '638_Grey_4'=>array( 'alias'=>'gray4',
                  'hex'=>"#A0A0A0",
                  'class'=>'638_Grey_4'
                ),
  '639_Grey_5'=>array(
                  'alias'=>'gray5',
                  'hex'=>"#B8B8B8",
                  'class'=>'639_Grey_5'
                ),
  '641_Grey_6'=>array(
                  'alias'=>'gray6',
                  'hex'=>"#D0D0D0",
                  'class'=>'641_Grey_6'
                ),
  '613_White'=>array(
                  'alias'=>'white',
                  //'hex'=>'yellow'
                  'hex'=>"#FFFFFF",
                  'class'=>'613_White'
                )
);

$s1 =array(
  'dim'=> array(
    0=>array(1,0,0),
    1=>array(0,0,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x1"
);

  $s2a =array(
    'dim'=> array(
      0=>array(1,0,0),
      1=>array(1,0,0),
      2=>array(0,0,0)
    ),
    'color'=>NULL,
    'item'=>"1x2"
  );

  $s2b =array(
    'dim'=> array(
     0=>array(1,1,0),
     1=>array(0,0,0),
     2=>array(0,0,0)
   ),
   'color'=>NULL,
   'item'=>"2x1"
 );

 $s3 =array(
   'dim'=> array(
    0=>array(1,1,0),
    1=>array(1,1,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2"
 );

 $s4a =array(
   'dim'=> array(
    0=>array(1,1,0),
    1=>array(1,0,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner"
 );

 $s4b =array(
   'dim'=> array(
    0=>array(1,1,0),
    1=>array(0,1,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_90"
 );

 $s4c =array(
   'dim'=> array(
    0=>array(0,1,0),
    1=>array(1,1,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_180"
 );

 $s4d =array(
   'dim'=> array(
    0=>array(1,0,0),
    1=>array(1,1,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"2x2_Corner_270"
 );

 $s5a =array(
   'dim'=> array(
    0=>array(1,0,0),
    1=>array(1,0,0),
    2=>array(1,0,0)
  ),
  'color'=>NULL,
  'item'=>"1x3"
 );

 $s5b =array(
   'dim'=> array(
    0=>array(1,1,1),
    1=>array(0,0,0),
    2=>array(0,0,0)
  ),
  'color'=>NULL,
  'item'=>"3x1"
 );

$shapes = array(
  '1x1'=> $s1,
  '1x2'=> $s2a,
  '2x1'=> $s2b,
  '2x2'=> $s3,
  '2x2_Corner'=> $s4a,
  '2x2_Corner_90'=> $s4b,
  '2x2_Corner_180'=> $s4c,
  '2x2_Corner_270'=> $s4d,
  '1x3'=> $s5a,
  '3x1'=> $s5b
  );


/*
//print_r($shapes['s1']); //gets all data for shape s1
foreach ($shapes as $s)
{
  echo "<pre>";
  print_shape($s);
  echo "</pre>";
}
*/

//echo json_encode($shapes['s5']);





/*
//js console code

var s5 = {"dim":[[1,1,0],[1,0,0],[0,0,0]],"color":"#000000"}
console.log(s5);
s5.color = "#F11111";
console.log(s5);

*/

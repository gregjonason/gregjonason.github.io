
#!/opt/local/bin/perl -w

use strict;
use warnings;
use 5.012;
 
my $file = 'file copy.txt';
open my $fh, '<', $file or die "Could not open '$file' $!\n";
open(OUT_FILE,">out_file") || die "cant open file...";
 
while (my $line = <$fh>) {
   chomp $line;
   my @strings = $line =~ /(\n\s+\$\d+,\d+)(.*\n\n)(Average Household Income\n\n)/g;
   foreach my $s (@strings) {
     say "'$s'";
     print OUT_FILE "'$s'";
   }
     print OUT_FILE "\n";
}
close(OUT_FILE);
close($fh);
